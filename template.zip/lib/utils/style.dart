class AppStyles {

}