import 'package:flutter/material.dart';

ThemeData light() => ThemeData(
  fontFamily: "mulish",
);
